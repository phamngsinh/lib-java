#! /bin/sh
# NOTE: Syntax console.sh [network password]

java -cp ../../lib/Mckoi*.jar com.mckoi.runtime.AdminConsole -netpassword $1