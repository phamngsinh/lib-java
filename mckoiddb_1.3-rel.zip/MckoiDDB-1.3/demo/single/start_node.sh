#!/bin/sh

java -cp ../../lib/Mckoi*.jar com.mckoi.runtime.MckoiMachineNode -host 127.0.0.1 -port 3500
