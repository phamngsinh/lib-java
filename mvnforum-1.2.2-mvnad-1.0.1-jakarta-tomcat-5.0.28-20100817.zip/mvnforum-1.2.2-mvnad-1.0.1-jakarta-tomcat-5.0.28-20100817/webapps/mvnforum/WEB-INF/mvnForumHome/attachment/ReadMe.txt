This directory will contain all uploaded attachments.
