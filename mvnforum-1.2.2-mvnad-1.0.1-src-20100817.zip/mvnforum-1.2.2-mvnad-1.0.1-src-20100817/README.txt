====================================================================
  $Id: README.txt,v 1.1.2.1 2009/03/10 10:45:58 minhnn Exp $
====================================================================
          Quick Readme for mvnForum and mvnAd Source Package
====================================================================

1/ The documentation is in folder mvnforum/docs and mvnad/docs in this package

2/ For installation, please read mvnforum/docs/INSTALL.txt

3/ Release Note at link:
   http://www.mvnforum.com/mvnforum/viewthread_thread,4218
   
4/ Online Wiki Documentation is at link:
   http://www.mvnforum.com/mvnforumwiki/
   
5/ This package include 2 application: mvnforum and mvnad
   
6/ For more information about mvnForum Professional Service, please visit:
   http://www.myvietnam.net/myvietnam/myvietnam/mvnforumservices

7/ We also provide Offshore Development and Outsourcing Service with lower cost, 
   high quality and quicker time to market solution for your projects. Please read more at:
   http://www.myvietnam.net/myvietnam/myvietnam/outsourcing
   
8/ If you have any inquiry, please do not hesitate to contact us at:
   http://www.myvietnam.net/myvietnam/myvietnam/contact 
   
9/ We include Profile of our Company as a reference.
   Please read MVN_Profile_standard_20081002.pdf


Thanks for using mvnForum

Minh Nguyen
MVN Products Manager
Huu Ngoc Joint Stock Company

