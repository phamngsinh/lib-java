SPRING WEB SERVICES

This directory contains a Java client for the Airline Web Service that uses JAX-RPC.
The client can be run from the provided ant file, by calling "ant run".

SAJA Client Sample table of contents
---------------------------------------------------
* src - The source files for the client
* build.xml -  Ant build file with a 'build' and a 'run' target

