=======================================================
== Spring Web Service Stock Quote sample application ==
=======================================================


1. INTRODUCTION

This sample shows a Stock Quote service. Incoming messages are routed via
WS-Addressing, and SOAP message content is handled using JAXB2. Additionally, 
this sample uses the HTTP server built into Java 6. 

2. RUNNING

This sample contains a main() method in the Driver class. To start it, simply
run "mvn install exec:java" in the server directory

3. CLIENT

Simply run "mvn install exec:java" in each of the client subdirectories.
