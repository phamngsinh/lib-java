=================================
== Spring Web Service Tutorial ==
=================================


1. INTRODUCTION

This sample contains the code for the tutorial, which can be found at 
http://static.springframework.org/spring-ws/site/reference/html/tutorial.html

2. INSTALLATION

Simply run "mvn package" and deploy the war file generated in target
